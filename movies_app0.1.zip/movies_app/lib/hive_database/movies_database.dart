import 'package:hive/hive.dart';

part 'movies_database.g.dart';

@HiveType(typeId: 0)
class MovieCacheData extends HiveObject {
  @HiveField(0)
  int id;

  @HiveField(1)
  String title;

  @HiveField(2)
  String overview;

  @HiveField(3)
  String posterPath;

  @HiveField(4)
  String backdropPath; // Add this line

  MovieCacheData({
    required this.id,
    required this.title,
    required this.overview,
    required this.posterPath,
    required this.backdropPath, // Add this line
  });
}



class HiveBoxes {
  static const String movies = 'movies';
}

Future<void> openHiveBox() async {
  await Hive.openBox<MovieCacheData>(HiveBoxes.movies,);
}

Future<void> closeHiveBox() async {
  await Hive.close();
}
