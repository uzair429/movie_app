// movie_api_client.dart
import 'package:dio/dio.dart';
import '../model/movie_model.dart';

class MovieApiClient {
  final Dio dio = Dio();
  final  apiKey = '0fa770fd29aa7a27d41ac44747546479';

  Future<List<Movie>> fetchMovies() async {
    print('api called');
    final response = await dio.get(
      'https://api.themoviedb.org/3/movie/upcoming',
      queryParameters: {
        'api_key': apiKey,
      },
    );
    return List<Map<String, dynamic>>.from(response.data['results'])
        .map((json) => Movie.fromJson(json))
        .toList();
  }
}