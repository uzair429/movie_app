import 'package:flutter/material.dart';

class DetailScreen extends StatelessWidget {
  final movie;
  const DetailScreen({Key? key, required this.movie}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final height = MediaQuery.of(context).size.height;
    return Scaffold(
      body: OrientationBuilder(
        builder: (context, orientation) {
          if (orientation == Orientation.portrait) {
            return _buildPortraitLayout(context);
          } else {
            return _buildLandscapeLayout(context);
          }
        }
      ),
    );
  }

  _buildPortraitLayout(context){
    final height = MediaQuery.of(context).size.height;
    return SingleChildScrollView(
      child: Column(
          children:[
            Container(
                color: const Color(0xffDBDBDF),
                height: height * .75,
                child: Stack(
                  children: [
                    SizedBox.expand(
                      child: Image.network(
                        movie.posterPath,
                        fit : BoxFit.cover,
                        loadingBuilder: (BuildContext context, Widget child, ImageChunkEvent? loadingProgress) {
                          if (loadingProgress == null) {
                            return child; // If there's no progress, display the image
                          } else {
                            return Center(
                              child: CircularProgressIndicator(
                                value: loadingProgress.expectedTotalBytes != null
                                    ? loadingProgress.cumulativeBytesLoaded /
                                    (loadingProgress.expectedTotalBytes ?? 1)
                                    : null,
                              ),
                            );
                          }
                        },
                        errorBuilder: (context, error, stackTrace) {
                          // Display a fallback image when the network image fails to load
                          return Icon(
                            Icons.image,
                            size: 200,
                          );
                        },
                      ),
                    ),
                    SafeArea(
                        child: Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: Row(
                            children: [
                              IconButton(
                                  onPressed: (){
                                    Navigator.of(context).pop();
                                  },
                                  icon: Icon(Icons.arrow_back_ios,color: Colors.white,)),
                              // SizedBox(width: 6,),
                              Text(
                                'Watch',
                                style: const TextStyle(
                                    fontSize: 18,
                                    color: Colors.white,
                                    fontWeight: FontWeight.bold,
                                    fontFamily: 'Poppins'
                                ),),
                            ],
                          ),
                        )),
                    Align(
                      alignment: Alignment.bottomCenter,
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          SizedBox(
                            height: 50,
                            width: 230,
                            child: ElevatedButton(
                                onPressed: (){},
                                style: ElevatedButton.styleFrom(
                                    backgroundColor: Color(0xff61C3F2),
                                    shape: RoundedRectangleBorder(
                                        borderRadius: BorderRadius.circular(12)
                                    )
                                ),
                                child: Text('Get Ticket',style: TextStyle(
                                    fontSize: 18,
                                    color: Colors.white,
                                    fontFamily: 'Poppins'
                                ),
                                )),
                          ),
                          Container(
                            margin: EdgeInsets.all(12),
                            height: 50,
                            width: 230,
                            child: OutlinedButton.icon(
                                onPressed: (){},
                                style: ElevatedButton.styleFrom(
                                    side: BorderSide(color: Color(0xff61C3F2) ),
                                    shape: RoundedRectangleBorder(
                                        borderRadius: BorderRadius.circular(12)
                                    )
                                ),
                                icon :Icon(Icons.play_arrow_rounded,color: Colors.white,),
                                label: Text(
                                  'Watch Trailer',
                                  style: TextStyle(
                                      fontSize: 18,
                                      color: Colors.white,
                                      fontFamily: 'Poppins'
                                  ),
                                )),
                          )
                        ],
                      ),
                    )
                  ],
                )),
            Row(
              children: [
                Padding(
                  padding: const EdgeInsets.all(18.0),
                  child: Text(
                    'Overview',
                    style:  const TextStyle(
                        fontSize: 18,
                        color: Colors.black,
                        fontWeight: FontWeight.bold,
                        fontFamily: 'Poppins'
                    ),
                  ),
                ),
              ],
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 22.0),
              child: Text(
                movie.overview,
                style:  const TextStyle(
                    fontSize: 12,
                    color: Colors.grey,
                    fontFamily: 'Poppins'
                ),
              ),
            )
          ]
      ),
    );
  }


  _buildLandscapeLayout(context){
    final width = MediaQuery.of(context).size.width;
    return Row(
        children:[
          Expanded(
            child: Container(
                color: const Color(0xffDBDBDF),
                child: Stack(
                  children: [
                    Image.network(
                      movie.posterPath,
                      width : width/2,
                      fit: BoxFit.cover,
                      loadingBuilder: (BuildContext context, Widget child, ImageChunkEvent? loadingProgress) {
                        if (loadingProgress == null) {
                          return child; // If there's no progress, display the image
                        } else {
                          return Center(
                            child: CircularProgressIndicator(
                              value: loadingProgress.expectedTotalBytes != null
                                  ? loadingProgress.cumulativeBytesLoaded /
                                  (loadingProgress.expectedTotalBytes ?? 1)
                                  : null,
                            ),
                          );
                        }
                      },
                      errorBuilder: (context, error, stackTrace) {
                        // Display a fallback image when the network image fails to load
                        return Icon(
                          Icons.image,
                          size: 200,
                        );
                      },
                    ),
                    SafeArea(
                        child: Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: Row(
                            children: [
                              IconButton(
                                  onPressed: (){
                                    Navigator.of(context).pop();
                                  },
                                  icon: Icon(Icons.arrow_back_ios,color: Colors.white,)),
                              // SizedBox(width: 6,),
                              Text(
                                'Watch',
                                style: const TextStyle(
                                    fontSize: 18,
                                    color: Colors.white,
                                    fontWeight: FontWeight.bold,
                                    fontFamily: 'Poppins'
                                ),),
                            ],
                          ),
                        )),
                    Align(
                      alignment: Alignment.bottomCenter,
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          SizedBox(
                            height: 50,
                            width: width * .2,
                            child: ElevatedButton(
                                onPressed: (){},
                                style: ElevatedButton.styleFrom(
                                    backgroundColor: Color(0xff61C3F2),
                                    shape: RoundedRectangleBorder(
                                        borderRadius: BorderRadius.circular(12)
                                    )
                                ),
                                child: Text('Get Ticket',style: TextStyle(
                                    fontSize:  width * .02,
                                    color: Colors.white,
                                    fontFamily: 'Poppins'
                                ),
                                )),
                          ),
                          Container(
                            margin: EdgeInsets.all(12),
                            height: 50,
                            width: width * .25,
                            child: OutlinedButton.icon(
                                onPressed: (){},
                                style: ElevatedButton.styleFrom(
                                    side: BorderSide(color: Color(0xff61C3F2) ),
                                    shape: RoundedRectangleBorder(
                                        borderRadius: BorderRadius.circular(12)
                                    )
                                ),
                                icon :Icon(Icons.play_arrow_rounded,color: Colors.white,),
                                label: Text(
                                  'Watch Trailer',
                                  style: TextStyle(
                                      fontSize: width * .02,
                                      color: Colors.white,
                                      fontFamily: 'Poppins'
                                  ),
                                )),
                          )
                        ],
                      ),
                    )
                  ],
                )),
          ),
          Expanded(
            child: Column(
              children: [
                Padding(
                  padding: const EdgeInsets.all(22.0),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      Text(
                        'Overview',
                        style:  const TextStyle(
                            fontSize: 18,
                            color: Colors.black,
                            fontWeight: FontWeight.bold,
                            fontFamily: 'Poppins'
                        ),
                      ),
                    ],
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 22.0),
                  child: Text(
                    movie.overview,
                    style:  const TextStyle(
                        fontSize: 12,
                        color: Colors.grey,
                        fontFamily: 'Poppins'
                    ),
                  ),
                ),
              ],
            ),
          )
        ]
    );
  }
}
